<!DOCTYPE html>
<html><head>
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
<title>Check Whether Internet Connection Exists - jQuery, Javascript</title>
</head><body>
<div id="content" style="margin-top:10px;">
 <h1>Check Whether Internet Connection Exists - jQuery, Javascript</h1>
 <a id="check"><center style="border:2px solid black;padding:10px;background:#EEE;font-size:40px;cursor:pointer;">CHECK NOW (jQuery)</center></a>
 <br/>
 <a onclick="onJSButtonclick();return false;"><center style="border:2px solid black;padding:10px;background:#EEE;font-size:40px;cursor:pointer;">CHECK NOW (JS)</center></a>
</div>
<script>
function checkJSNetConnection(){
 var xhr = new XMLHttpRequest();
 var file = "dot.png";
 var r = Math.round(Math.random() * 10000); 
 xhr.open('HEAD', file + "?subins=" + r, false); 
 try {
  xhr.send(); 
  if (xhr.status >= 200 && xhr.status < 304) {
   return true;
  } else {
   return false;
  }
 } catch (e) {
  return false;
 }
}
function onJSButtonclick(){
 if(checkJSNetConnection()==true){
  alert("Internet Connection Exists");
 }else{
  alert("Internet Connection Doesn't Exist");
 }
}
function checkNetConnection(){
 jQuery.ajaxSetup({async:false});
 re="";
 r=Math.round(Math.random() * 10000);
 $.get("dot.png",{subins:r},function(d){
  re=true;
 }).error(function(){
  re=false;
 });
 return re;
}
$(document).ready(function(){
 $("#check").on('click',function(){
  if(checkNetConnection()==true){
   alert("Internet Connection Exists");
  }else{
   alert("Internet Connection Doesn't Exist");
  }
 });
});
</script>
<!-- http://www.subinsb.com/2013/10/check-if-internet-connection-exist-jquery-javascript.html -->
</body></html>
