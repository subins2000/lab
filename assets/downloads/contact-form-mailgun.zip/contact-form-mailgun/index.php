<!DOCTYPE html>
<html>
 <head>

 </head>
 <body>
  <div id="content" style="margin-top:10px;height:100%;">
   <center>
    <h1></h1>
   </center>
   <form action="contact.php" method="POST">
    Name<br/>
    <input type="text" name="name" placeholder="Your Name" size="40"/><br/>
    Message<br/>
    <textarea name="message" cols="40" rows="10"></textarea><br/>
    <input type="submit" value="Send Message" name="submit"/>
   </form>
 </body>
</html>
