<!DOCTYPE html>
<html><head>
<title>Password for .HTPASSWD Generator</title>
</head><body>
<div id="content" style="margin-top:10px;height:70%;">
<h2><u>Password for .HTPASSWD Generator</u></h2><br/>
<div style="height:80%;width:97%;border:2px solid black;padding:10px 8px;">
<form method="POST" action="">
 Username : <input type="text" name="user"/><br/>
 Password : <input type="password" name="pass"/><br/>
 <input type="submit"/> 
</form>
<?
if(isset($_POST) && $_POST['user']!='' && $_POST['pass']!=''){
 $p=$_POST['pass'];
 $p=crypt($p,base64_encode($p));
 echo '<h3>Copy the text below to your .htpasswd file :</h3>';
 echo '<textarea cols="55" rows="5">'.$_POST['user'].':'.$p.'</textarea>';
}
?>
<!-- http://www.subinsb.com/2013/08/use-htaccess-to-password-protect-folders.html -->
</div>
</body></html>
