<!DOCTYPE html>
<html>
 	<head>
  		<script src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
  		<script src="form.js"></script>
  		<link href="form.css" rel="stylesheet" />
 	</head>
 	<body>
  		<div id="content">
			<h1>jQuery AJAX Login Form</h1>
			<div class="loginForm">
				<label>
					<span>Username</span>
					<input type="text" name="username" />
				</label>
				<label>
					<span>Password</span>
					<input type="password" name="password" />
				</label>
				<div class="submit">Log In</div>
				<div class="overlay">
					<div class="message processing">
						<h2>Logging In</h2>
					</div>
					<div class="message error">
						<h2>Incorrect Credentials</h2>
						<p>The username or password you entered was not correct</p>
					</div>
					<div class="message success">
						<h2>Logged In</h2>
						<p>You have been logged in</p>
					</div>
				</div>
			</div>
  		</div>
  		<!-- http://subinsb.com/jquery-animated-ajax-login-form -->
 	</body>
</html>