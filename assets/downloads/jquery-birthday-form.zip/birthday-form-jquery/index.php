<!DOCTYPE html>
<html>
 <head>
  <link href="datepicker.css" rel="stylesheet"/>
  <script src="http://code.jquery.com/jquery-latest.min.js"></script>
  <script src="datepicker.js"></script>
  <script src="birthchecker.js"></script>
  <title>jQuery Birthday Form Field & Checker</title>
 </head>
 <body>
  <div id="content" style="margin-top:10px;height:100%;">
   <center><h1>jQuery Birthday Form Field & Checker</h1></center>
   <form method="POST" action="submit.php">
    <table><tbody>
     <tr>
      <td>Birthday :</td>
      <td><input id="birth" name="birth" value="2000-01-20"/><div id="ermsg">Users under 13 are not allowed.</div></td>
      <td>YY-MM-DD</td>
     </tr>
     <tr>
      <td></td>
      <td><input type="submit"/></td>
     </tr>
    </tbody></table>
   </form>
  </div>
  <style>
  input{
   border:none;
   padding:8px;
  }
  #ermsg{
   display:none;
   color:red;
  }
  </style>
<!-- http://www.subinsb.com/2013/10/add-simple-birthday-field-in-form-jquery-and-validate-in-php.html -->
 </body>
</html>
