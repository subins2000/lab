<?php
// ini_set("display_errors","on");
$docRoot	= realpath(dirname(__FILE__));
if( !isset($dbh) ){
	session_start();
	date_default_timezone_set("UTC");
	$host = "localhost"; // Hostname
	$port = "3306"; // MySQL Port : Default : 3306
	$user = "username"; // Username Here
	$pass = "password"; //Password Here
	$db   = "database_name"; // Database Name
	$dbh  = new PDO('mysql:dbname='.$db.';host='.$host.';port='.$port,$user,$pass);
	/* Change The Credentials to connect to database. */
	include_once "$docRoot/inc/startServer.php";
}
?>