<?php
require_once realpath(__DIR__) . "/../config.php";
$startNow = 1;
include_once "$docRoot/inc/server.php";
?>