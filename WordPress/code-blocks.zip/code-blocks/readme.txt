=== Plugin Name ===
Contributors: Subin Siby
Donate link: http://subinsb.com/donate
Tags: wordpress, code, blocks, post, pages, posts, page
Requires at least: 3.0.1
Tested up to: 3.9
Stable tag: 0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add Code Blocks to your posts and pages. Customize the code blocks and add custom CSS to the WordPress Visual Editor.

== Description ==

Add Code Blocks to your posts and pages. Customize the code block code to wrap and add custom CSS to the WordPress Visual Editor.
See More Details : http://subinsb.com/posting-code-blocks-on-wordpress

**Compatibilty**

Code Blocks works on Wordpress versions from 3.0.1 to the latest WordPress version without any problem.

**Donate**

I'm only 14 years old when writing this plugin. Please consider a donation to support me. Please....
http://subinsb.com/donate

**Support**

If you want help, you can use the WordPress Support Forum or you can seek help via comments section of ttp://subinsb.com/ask/code-blocks

== Installation ==

1. Upload `code-blocks` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

No questions has been asked yet. 
If you have a question, ask using 
 http://subinsb.com/ask/code-blocks
comments page or via WordPress support forum.

== Screenshots ==

See Screenshots in this page : http://subinsb.com/posting-code-blocks-on-wordpress

== Changelog ==
= 0.3 =
Fixed Custom Styles in Text Editor bug
Fixed bug of image editing handle bars not showing

= 0.2 =
Fixed <p> Tag Bug

= 0.1 =
Initial Version.