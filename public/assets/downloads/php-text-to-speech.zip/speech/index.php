<!DOCTYPE html>
<html>
 <head>
  <title>Text To Speech</title>
 </head>
 <body>
  <div id="content" style="margin-top:10px;height:100%;">
   <center><h1>Text To Speech</h1></center>
   <form action="index.php" method="POST">
    <textarea name="msg" cols="40" rows="10"></textarea><br/>
    <input type="submit" name="submit" value="Make It Speak"/>
   </form>
   Make sure the text you submit doesn't exceed 100 <br/>characters, because it won't work.<br/><b>Your browser should support HTML5 audio element</b>
   <?
   if(isset($_POST['submit'])){
    $msg=urlencode($_POST['msg']);
    echo "<h2>Audio Output</h2><audio autoplay controls src='get_sound.php?text=$msg'></audio>";
   }
   ?>
  </div>
 </body>
</html>
