<!DOCTYPE html>
<html>
 <head>
  <script src="http://code.jquery.com/jquery-latest.min.js"></script>
  <script src="passchecker.js"></script>
  <title>Simple jQuery Password Strength Checker</title>
 </head>
 <body>
  <div id="content" style="margin-top:10px;height:100%;">
   <center><h1>Simple jQuery Password Strength Checker</h1></center>
   <table><tbody>
    <tr>
     <td>
      Username :
     </td>
     <td>
      <input type="text" size="35" id="user" placeholder="Username"/>
     </td>
    </tr>
    <tr>
     <td>
      Password :
     </td>
     <td>
      <input type="password" size="35" id="pass" placeholder="Type A Password"/>
     </td>
    </tr>
    <tr>
     <td></td>
     <td>
      <div id="ppbar" title="Strength"><div id="pbar"></div></div>
      <div id="ppbartxt"></div>
     </td>
    <tr>
     <td>
      Retype Password :
     </td>
     <td>
      <input type="password" size="35" id="pass2" placeholder="ReType Password"/>
     </td>
    </tr>
   </tbody></table>
  </div>
  <style>
  input{
   border:none;
   padding:8px;
  }
  #ppbar{
   background:#CCC;
   width:300px;
   height:15px;
   margin:5px;
  }
  #pbar{
   margin:0px;
   width:0px;
   background:lightgreen;
   height: 100%;
  }
  #ppbartxt{
   text-align:right;
   margin:2px;
  }
  </style>
<!-- http://www.subinsb.com/2013/10/create-simple-password-strength-checker-using-jquery.html -->
 </body>
</html>
