<?php
include "config.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <title>PHP logSys</title>
  </head>
  <body>
    <div id="content" style="font-size:15px;">
      <center><h1><?php echo $parr[$id]['title'];?></h1></center>
      <a href="login.php">Log In</a><br/>
      <a href="register.php">Register</a><br/>
      <a href="reset.php">Forgot Password ?</a>
    </div>
    <!-- https://subinsb.com/php-logsys -->
  </body>
</html>
