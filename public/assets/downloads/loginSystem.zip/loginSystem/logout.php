<?
require "config.php";
\Fr\LS::logout();
?>
