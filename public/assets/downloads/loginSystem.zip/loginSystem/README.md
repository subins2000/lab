The class.logsys.php file and other files here may be not be the latest one.
So, please update it from https://github.com/subins2000/logSys/blob/master/class.logsys.php
