<?include("config.php");include("login.php");?>
<!DOCTYPE html>
<html>
 <head>
  <script src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
  <script src="chat.js"></script>
  <link href="chat.css" rel="stylesheet"/>
  <title>Group Chat In PHP With Users' Typing Status</title>
 </head>
 <body>
  <div id="content" style="margin-top:10px;height:100%;">
   <center><h1>Group Chat In PHP With Users' Typing Status</h1></center>
   <div class="chat">
    <div class="users">
     <?include("users.php");?>
    </div>
    <div class="chatbox">
     <?
     if(isset($_SESSION['user'])){
      include("chatbox.php");
     }else{
      $display_case=true;
      include("login.php");
     }
     ?>
    </div>
   </div>
  </div>
  <?/* http://subinsb.com/php-group-chat-with-user-type-status */?>
 </body>
</html>
