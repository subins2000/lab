<?
include("config.php");
$user=strtolower($_POST['user']);
if(isset($_POST) && $user!=''){
 $sql=$dbh->prepare("SELECT * FROM users WHERE username=?");
 $sql->execute(array($user));
 if($sql->rowCount()==0){
  echo "available";
 }else{
  echo "not-available";
 }
}
?>
