<!DOCTYPE html>
<html>
 <head>
  <script src="http://code.jquery.com/jquery-latest.min.js"></script>
  <script src="checker.js"></script>
  <title>HTML, CSS, JS Code Editor Using jQuery</title>
 </head>
 <body>
  <div id="content" style="margin-top:10px;height:100%;">
   <center><h1>jQuery Username Availablity Checker</h1></center>
   <input type="text" size="35" id="user" value="subinsiby" placeholder="Type Your Desired Username"/>
   <input type="button" id="check" style="cursor:pointer;" value="Check Availablity"/>
   <br/>
   <div style="margin:5px 15px;" id="msg">http://mysite.com/<b id="prev">subinsiby</b></div>
  </div>
  <style>
  input{
   border:none;
   padding:8px;
  }
  </style>
<!-- http://www.subinsb.com/2013/10/create-simple-username-availability-checker-jquery.html -->
 </body>
</html>
