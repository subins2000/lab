<!DOCTYPE html>
<html><head>
<title>Google PHP Library Simplified Demo</title>
<script>
function opesn(){
new_window = window.open('server.php','name','height=400,width=500');
}
function foo(k){
window.location="server.php?info=true&code="+k;
}
</script>
</head><body>
<?include('../top.php');?>
<div id="content" style="margin-top:10px;height:70%;">
<h2><u>Google PHP Library Simplified Demo</u></h2><br/>
<div style="height:60%;width:97%;border:2px solid black;padding:10px 8px;"><img onclick="opesn();" src="http://accounts.subins.com/files/images/pluslogin.png">
<!-- http://www.subinsb.com/2013/04/login-with-google-oauth-without-using.html -->
</div>
</body></html>
